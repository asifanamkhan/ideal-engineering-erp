{{-- resources/views/admin/hrm/attendance/partials/matrix-table.blade.php --}}

@php
$leaveTypes = DB::table('leave_types')->where('status', 1)->get();
$currentDate = date('Y-m-d');
$weekends = DB::table('weekend_settings')->where('status', 1)->pluck('day_number')->toArray();
@endphp
<div id="attendanceNotice" class="alert alert-warning" style="">
    <i class="fas fa-info-circle me-2"></i>
    <span id="noticeMessage">You can update attendance by clicking on the day cell</span>
</div>

<table class="table table-sm table-bordered attendance-matrix">
    <thead class="">
        <tr>
            <th rowspan="2"
                style="vertical-align: middle; position: sticky; left: 0; background: #28A745; z-index: 15;">#</th>
            <th rowspan="2"
                style="vertical-align: middle; position: sticky; left: 0px; background: #28A745; z-index: 15;">Employee
            </th>
            @foreach($dates as $date)
            <th style="text-align: center; min-width: 60px;">
                {{ $date['day'] }}<br>
                <small>{{ $date['day_name'] }}</small>
                <br><small class="" style="font-size: 9px;">{{ $date['date'] }}</small>
            </th>
            @endforeach
            <th rowspan="2" style="vertical-align: middle;">Present</th>
            <th rowspan="2" style="vertical-align: middle;">Absent</th>
            <th rowspan="2" style="vertical-align: middle;">Total</th>
            <th rowspan="2" style="vertical-align: middle;">%</th>
        </tr>
    </thead>
    <tbody>
        @foreach($matrixData as $index => $row)
        @php
        // Reset counts for this employee based on non-weekend days only
        $presentCount = 0;
        $absentCount = 0;
        $totalWorkingDays = 0;

        foreach($row['attendance'] as $attIndex => $att) {
        $isWeekend = in_array(\Carbon\Carbon::parse($att['date'])->dayOfWeek, $weekends);
        if (!$isWeekend) {
        $totalWorkingDays++;
        if ($att['status'] == 'present') {
        $presentCount++;
        } elseif ($att['status'] == 'absent') {
        $absentCount++;
        }
        }
        }

        $attendancePercentage = $totalWorkingDays > 0 ? round(($presentCount / $totalWorkingDays) * 100, 2) : 0;
        @endphp

        <tr>
            <td style="position: sticky; left: 0; background: white; z-index: 5;">{{ $index + 1 }}</td>
            <td style="position: sticky; left: 0px; background: white; z-index: 5; text-align: left;">
                <div class="employee-info-cell">
                    <strong>{{ $row['name'] }}</strong><br>
                    <small class="text-muted">ID: {{ $row['employee_id'] }}</small>,
                    <small class="text-muted">DESG:{{ $row['designation'] }}</small>
                </div>
            </td>

            @foreach($row['attendance'] as $attIndex => $att)
            @php
            $statusClass = '';
            $statusText = '';
            $onLeave = false;

            // Check if date is future
            $isFuture = $att['date'] > $currentDate;

            // Check if date is weekend
            $dayOfWeek = \Carbon\Carbon::parse($att['date'])->dayOfWeek;
            $isWeekend = in_array($dayOfWeek, $weekends);

            if ($isWeekend) {
            $statusClass = 'weekend-cell';
            $statusText = 'W';
            } elseif ($att['status'] == 'present') {
            $statusClass = 'present-cell';
            $statusText = 'P';
            } elseif ($att['status'] == 'absent') {
            $statusClass = 'absent-cell';
            $statusText = 'A';
            } elseif ($att['status'] == 'on_leave') {
            $statusClass = 'leave-cell';
            $statusText = 'L';
            $onLeave = true;
            } else {
            $statusClass = 'not-recorded-cell';
            $statusText = 'NR';
            }

            $canEdit = !$isFuture && !$onLeave && !$isWeekend;
            @endphp
            <td class="{{ $statusClass }} {{ $canEdit ? 'editable' : '' }}" data-employee-id="{{ $row['id'] }}"
                data-employee-name="{{ $row['name'] }}" data-date="{{ $att['date'] }}"
                data-status="{{ $att['status'] }}" data-check-in="{{ $att['check_in'] ?? '09:00' }}"
                data-check-out="{{ $att['check_out'] ?? '17:00' }}" data-leave-type="{{ $att['leave_type_id'] ?? '' }}"
                data-remarks="{{ $att['remarks'] ?? '' }}" data-on-leave="{{ $onLeave ? 'true' : 'false' }}"
                data-is-weekend="{{ $isWeekend ? 'true' : 'false' }}" {!! !$canEdit ? 'style="cursor: not-allowed;"'
                : 'style="cursor: pointer;"' !!}>
                <span class="status-badge">{{ $statusText }}</span>
                @if($isWeekend)
                <div class="updated-info">Weekend</div>
                @endif
            </td>
            @endforeach

            <td class="present-cell"><strong>{{ $presentCount }}</strong></td>
            <td class="absent-cell"><strong>{{ $absentCount }}</strong></td>
            <td><strong>{{ $totalWorkingDays }}</strong></td>
            <td>
                <div class="d-flex align-items-center">
                    <div class="progress" style="height: 4px; width: 50px;">
                        <div class="progress-bar bg-success" role="progressbar"
                            style="width: {{ $attendancePercentage }}%"></div>
                    </div>
                    <span class="ms-1">{{ $attendancePercentage }}%</span>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
    <tfoot class="summary-row">
        <td></td>
        <td style="position: sticky; z-index: 14;" class="text-end"><strong>Summary:</strong></td>
        @php
        $totalPresent = 0;
        $totalAbsent = 0;
        $totalWorkingDaysOverall = 0;

        foreach($matrixData as $row) {
        foreach($row['attendance'] as $attIndex => $att) {
        $isWeekend = in_array(\Carbon\Carbon::parse($att['date'])->dayOfWeek, $weekends);
        if (!$isWeekend) {
        $totalWorkingDaysOverall++;
        if ($att['status'] == 'present') {
        $totalPresent++;
        } elseif ($att['status'] == 'absent') {
        $totalAbsent++;
        }
        }
        }
        }
        @endphp
        @foreach($dates as $index => $date)
        @php
        $dayPresent = 0;
        $isDateWeekend = in_array(\Carbon\Carbon::parse($date['date'])->dayOfWeek, $weekends);
        if (!$isDateWeekend) {
        foreach($matrixData as $row) {
        if (isset($row['attendance'][$index]['status']) && $row['attendance'][$index]['status'] == 'present') {
        $dayPresent++;
        }
        }
        }
        @endphp
        <td class="present-cell">
            @if(!$isDateWeekend)
            <small>P: {{ $dayPresent }}</small>
            @else
            <small>W</small>
            @endif
        </td>
        @endforeach
        <td><strong>{{ $totalPresent }}</strong></td>
        <td><strong>{{ $totalAbsent }}</strong></td>
        <td><strong>{{ $totalWorkingDaysOverall }}</strong></td>
        <td>
            @php
            $totalPercentage = $totalWorkingDaysOverall > 0 ? round(($totalPresent / $totalWorkingDaysOverall) * 100, 2)
            : 0;
            @endphp
            <strong>{{ $totalPercentage }}%</strong>
        </td>
    </tfoot>
</table>

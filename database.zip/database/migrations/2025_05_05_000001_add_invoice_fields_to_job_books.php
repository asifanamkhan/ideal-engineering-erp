<?php
// database/migrations/2025_05_05_000001_add_invoice_fields_to_job_books.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('job_books', function (Blueprint $table) {
            $table->enum('invoice_vat_type', ['include', 'exclude'])->default('include')->after('invoice_vat');
            $table->decimal('invoice_transport_cost', 12, 2)->default(0)->after('invoice_vat_type');
        });
    }

    public function down()
    {
        Schema::table('job_books', function (Blueprint $table) {
            $table->dropColumn('invoice_vat_type');
            $table->dropColumn('invoice_transport_cost');
        });
    }
};

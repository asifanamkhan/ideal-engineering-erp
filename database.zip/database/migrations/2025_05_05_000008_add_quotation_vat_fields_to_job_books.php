<?php
// database/migrations/2025_05_05_000008_add_quotation_vat_fields_to_job_books.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('job_books', function (Blueprint $table) {
            $table->enum('quotation_vat_type', ['include', 'exclude'])->default('include')->after('quotation_vat');
        });
    }

    public function down()
    {
        Schema::table('job_books', function (Blueprint $table) {
            $table->dropColumn('quotation_vat_type');
        });
    }
};

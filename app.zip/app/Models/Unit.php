<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{
    protected $table = "units";

    protected $fillable = [
        'name',
        'status',
        'description',
        'is_default',
    ];
}

<?php
// app/Http/Controllers/Admin/Hrm/HrmSettingController.php

namespace App\Http\Controllers\Admin\Hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class HrmSettingController extends Controller
{
    public function index()
    {
        $setting = DB::table('hrm_settings')->first();
        return view('admin.hrm.settings.index', compact('setting'));
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'default_check_in' => 'required',
            'default_check_out' => 'required',
            'default_overtime_hour' => 'required|numeric|min:0|max:24'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        DB::table('hrm_settings')->update([
            'default_check_in' => $request->default_check_in,
            'default_check_out' => $request->default_check_out,
            'default_overtime_hour' => $request->default_overtime_hour,
            'updated_at' => now()
        ]);

        return response()->json(['success' => true, 'message' => 'Settings updated successfully!']);
    }
}